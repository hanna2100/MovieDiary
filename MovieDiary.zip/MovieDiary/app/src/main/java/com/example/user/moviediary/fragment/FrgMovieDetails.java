package com.example.user.moviediary.fragment;

import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.drawable.GradientDrawable;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import com.example.user.moviediary.R;
import com.example.user.moviediary.etc.MovieDetails;
import com.example.user.moviediary.etc.MovieVideo;
import com.example.user.moviediary.util.GlideApp;
import com.example.user.moviediary.util.MoviesRepository;
import com.example.user.moviediary.util.OnGetDetailsCallback;
import com.example.user.moviediary.util.OnGetVideoCallback;


public class FrgMovieDetails extends Fragment {

    private final String TAG = "MovieDetails";
    private static final String MOVIE_ID = "MOVIE_ID";

    private View view;
    private Context mContext;
    private MoviesRepository moviesRepository;
    private LinearLayout llProgressBackground;
    private int movie_id;

    public static FrgMovieDetails newInstance(int movie_id) {
        FrgMovieDetails fragment = new FrgMovieDetails();

        Bundle args = new Bundle();
        args.putInt(MOVIE_ID, movie_id);
        fragment.setArguments(args);

        return fragment;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        mContext = context;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_movie_details, container, false);
        llProgressBackground = view.findViewById(R.id.llProgressBackground);
        moviesRepository = MoviesRepository.getInstance();

        new FrgMovieDetails.MyTask().execute();
        return view;
    }

    private class MyTask extends AsyncTask<Void, Void, Void> {

        //진행바표시
        private ProgressDialog progressDialog;

        @Override
        protected void onPreExecute() {
            //진행다이어로그 시작
            llProgressBackground.setVisibility(View.VISIBLE);
            progressDialog = new ProgressDialog(mContext);
            progressDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progressDialog.show();
            super.onPreExecute();
        }

        @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
        @Override
        protected Void doInBackground(Void... params) {

            final ImageView ivBackdrop = view.findViewById(R.id.ivBackdrop);
            final ImageView ivPoster = view.findViewById(R.id.ivPoster);
            final TextView tvTitle = view.findViewById(R.id.tvTitle);
            final TextView tvRuntime = view.findViewById(R.id.tvRuntime);
            final TextView tvRelease = view.findViewById(R.id.tvRelease);
            final TextView tvVoteAvg = view.findViewById(R.id.tvVoteAvg);
            final TextView tvNotFoundVideo = view.findViewById(R.id.tvNotFoundVideo);
            final RatingBar ratingBar = view.findViewById(R.id.ratingBar);
            Button btnWrite = view.findViewById(R.id.btnWrite);
            ImageButton ibLike = view.findViewById(R.id.ibLike);
            final TextView tvOverview = view.findViewById(R.id.tvOverview);

            //포스터 이미지뷰 모서리 둥글게
            GradientDrawable drawable =
                    (GradientDrawable) mContext.getDrawable(R.drawable.background_round);
            ivPoster.setBackground(drawable);
            ivPoster.setClipToOutline(true);


            final boolean[] dataComplete = {false};

            movie_id = getArguments().getInt(MOVIE_ID);

            moviesRepository.getMovieDetailsResult(movie_id, new OnGetDetailsCallback() {
                @Override
                public void onSuccess(MovieDetails movieDetails) {

                    Log.d(TAG, "영상여부"+movieDetails.isVideo());

                    tvTitle.setText(movieDetails.getTitle());
                    tvRuntime.setText(movieDetails.getRuntime() + "min");
                    tvRelease.setText(movieDetails.getRelease_date());
                    tvVoteAvg.setText(String.valueOf(movieDetails.getVote_average()));
                    ratingBar.setRating((float) movieDetails.getVote_average() / 2);
                    tvOverview.setText(movieDetails.getOverview());

                    String posterPath = "https://image.tmdb.org/t/p/w500" + movieDetails.getPoster_path();
                    GlideApp.with(view).load(posterPath)
                            .override(185, 260)
                            .into(ivPoster);
                    String backdropPath = "https://image.tmdb.org/t/p/w1280" + movieDetails.getBackdrop_path();
                    GlideApp.with(view).load(backdropPath)
                            .centerCrop()
                            .into(ivBackdrop);


                    getMovieUrlFromTMDB();

                    dataComplete[0] = true;

                }

                @Override
                public void onError() {

                }
            });

            while (true) {
                try {
                    Thread.sleep(100);
                    if (dataComplete[0] == true)
                        break;
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }

            return null;

        }

        private void getMovieUrlFromTMDB() {

            moviesRepository.getMovieVideoResult(movie_id, new OnGetVideoCallback() {
                @Override
                public void onSuccess(final MovieVideo movieVideo) {

                    String site = movieVideo.getResults().get(0).getSite();
                    if (site.equals("YouTube")) {
                        final String videoUrl = movieVideo.getResults().get(0).getKey();

                        FrgYoutubePlayer youtubePlayer = FrgYoutubePlayer.newInstance(videoUrl);
                        FragmentTransaction fragmentTransaction = getChildFragmentManager().beginTransaction();
                        fragmentTransaction.add(R.id.flYoutube, youtubePlayer).commit();


                    } else {
                        onError();
                    }
                }

                @Override
                public void onError() {

                }
            });

        }

        @Override
        protected void onPostExecute(Void result) {

            llProgressBackground.setVisibility(View.GONE);
            progressDialog.dismiss();

            super.onPostExecute(result);
        }


    }


}
